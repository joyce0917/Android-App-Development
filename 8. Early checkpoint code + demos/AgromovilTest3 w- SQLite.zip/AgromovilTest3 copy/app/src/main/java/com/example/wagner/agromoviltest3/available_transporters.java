package com.example.wagner.agromoviltest3;
        import android.app.ListActivity;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.widget.ListView;
        import android.widget.ArrayAdapter;

public class available_transporters extends AppCompatActivity {

    ListView lst;
    String[] transportername={"John","Richard","David"};
    String[] time={"1996 Toyota Tacoma","2002 Nissan Navara","2000 Agrale Marrua"};
    Integer[] imgid={R.drawable.image1,R.drawable.image2,R.drawable.image3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_available_transporters);

        lst= findViewById(R.id.listview);
        CustomListview customListview = new CustomListview(this,transportername,time,imgid);
        lst.setAdapter(customListview);
    }
}