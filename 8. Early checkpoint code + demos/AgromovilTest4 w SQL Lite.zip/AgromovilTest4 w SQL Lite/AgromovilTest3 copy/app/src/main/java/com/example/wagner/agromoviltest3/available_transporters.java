package com.example.wagner.agromoviltest3;
        import android.app.ListActivity;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.ListView;
        import android.widget.ArrayAdapter;

public class available_transporters extends AppCompatActivity {

    ListView lst;
    String[] transportername={"John","Richard","David"};
    String[] time={"1996 Toyota Tacoma","2002 Nissan Navara","2000 Agrale Marrua"};
    Integer[] imgid={R.drawable.image1,R.drawable.image2,R.drawable.image3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //chosenData is the day of the month.
        // Now you have the chosenData, do the things you wanted
        //int param = getIntent().getIntExtra("cat", 3);
        String value = getIntent().getExtras().getString("chosenDate");
        Log.d(value, "Value we recieved for day");
        Log.d("msg", value);

    setContentView(R.layout.activity_available_transporters);

        lst = findViewById(R.id.listview);
        CustomListview customListview = new CustomListview(this,transportername,time,imgid);
        lst.setAdapter(customListview);
    }
}