package com.example.wagner.avocado;

/**
 * Created by arkaroy on 12/3/17.
 */

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;


public class AppActivity extends AppCompatActivity implements TransporterReceived{

    @Override
    public void Success(String response) {

    }
}
