package com.example.wagner.avocado;

/**
 * Created by arkaroy on 12/3/17.
 */

import java.util.ArrayList;

public interface TransporterReceived
{
    public void Success(String response);
}
